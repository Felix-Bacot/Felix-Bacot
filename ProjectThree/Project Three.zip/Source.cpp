#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>


using namespace std;

// class to handle frequency counting and output
class ItemTracker {
public:
	// Contructor reads file and populate map
	ItemTracker(const string& inputFile) {
		LoadData(inputFile);
		WriteBackupFile("frequency.dat");
	}

	// Returns frequency of a specific item
	int GetFrequency(const string& item) const {
		auto it = itemFrequency.find(item);
		if (it != itemFrequency.end()) {
			return it->second;
		}
		return 0;
	}

	// Prints all items with their frequencies 
	void PrintAllFrequencies() const {
		for (auto const& entry : itemFrequency) {
			cout << entry.first << "" << entry.second << endl;
		}
	}

	// Prints histogram
	void PrintHistogram() const {
		for (auto const& entry : itemFrequency) {
		cout << setw(15) << left << entry.first << "";
		for (int i = 0; i < entry.second; ++i) {
			cout << "*";
		}
		cout << endl;

        }
	}
	
private:
	map<string, int> itemFrequency;

	// Loads data from the input file
	void LoadData(const string& filename) {
		ifstream inFile(filename);
		if (!inFile) {
			cerr << "Error: Could not open file " << filename << endl;
			exit(1);
		}
		string item;
		while (inFile >> item) {
			++itemFrequency[item];
		}
		inFile.close();
	}

	// Write backup data to frequency.dat
	void WriteBackupFile(const string& filename) const {
		ofstream outFile(filename);
		if (!outFile) {
			cerr << "Error: Could not create backup file." << endl;
			return;
		}
		for (auto const& entry : itemFrequency) {
			outFile << entry.first << " " << entry.second << endl;
		}
		outFile.close();
	}
};

// Display menu options
void DisplayMenu() {
	cout << "\n===== Corner Grocer Menu =====" << endl;
	cout << "1. Search for an item frequency" << endl;
	cout << "2. Print all item frequencies" << endl;
	cout << "3. Print histogram" << endl;
	cout << "4. Exit" << endl;
	cout << "Enter your choice: ";
}

int main() {
	ItemTracker tracker("CS210_Project_Three_Input_File.txt");
	int choice;
	string itemName;

	do {
		DisplayMenu();
		cin >> choice;

		switch (choice) {
		case 1:
			cout << "Enter item name: ";
			cin.ignore();
			getline(cin, itemName);
			cout << itemName << "" << tracker.GetFrequency(itemName) << endl;
			break;
		case 2:
			tracker.PrintAllFrequencies();
			break;
		case 3:
			tracker.PrintHistogram();
			break;
		case 4:
			cout << "Exiting program..." << endl;
			break;
		default:
			cout << "Invalid choice. Please try again." << endl;
			break;
		}
	} while (choice != 4);

	return 0;
}